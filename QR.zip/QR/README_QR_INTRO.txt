
==============================
KIRA INTRO QR PACKAGE (README)
==============================

Files:
- intro.html ............. Landing page: auto-plays INTRO.mp4, then shows the YouTube button.
- qr_intro_placeholder.png / qr_intro_placeholder.svg
                          .. QR code that points to a placeholder URL (https://your-domain.com/intro.html).
- (Place your INTRO.mp4 in the same folder as intro.html before deployment.)

How to deploy:
1) Upload BOTH files 'intro.html' and 'INTRO.mp4' to the SAME folder on your hosting (Netlify, Vercel, GitHub Pages with assets, or any static hosting / web server).
2) Note the final URL for 'intro.html', for example: https://your-domain.com/intro.html
3) Create a NEW QR code that points to the REAL URL from step 2 (the provided QR is a placeholder).
   - You can regenerate locally using Python qrcode (example below).

Regenerate QR with real URL (Python):
-------------------------------------
pip install qrcode[pil]

python:
------
import qrcode
url = "https://your-domain.com/intro.html"  # <- replace with your actual URL
img = qrcode.make(url)
img.save("qr_intro_REAL.png")

Tip:
- If you want a dynamic/replaceable URL without reprinting QR, create a short link (e.g., bit.ly) and use that in the QR.
  Later you can update the redirect at the shortener.
